﻿namespace StudyAid
{
    public class ConfigSettings
    {
        public string imageFileName { get; set; }
        public string textFileName { get; set; }
        public string time { get; set; }
    }
}
